package com.mib.rms.controller;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.awt.*;
import java.io.File;
import java.io.IOException;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;

import static org.slf4j.LoggerFactory.*;

@RestController
public class UploadController {


    private final static Logger log = getLogger(MethodHandles.lookup().lookupClass());


    @Value("${spring.http.multipart.location}")
    private String location;

    @RequestMapping(value="/upload", method= RequestMethod.POST, produces = MediaType.IMAGE_GIF_VALUE)
    public String upload(@RequestPart("file") MultipartFile file,
                         @RequestParam("start")  int start,
                         @RequestParam("end") int end,
                         @RequestParam("speed") int speed,
                         @RequestParam("repeat") boolean repeat) {


        try {

            File videoFile = new File(location + "/" + System.currentTimeMillis() + ".mp4");
            file.transferTo(videoFile);
            log.info("Saved file to {}",videoFile.getAbsolutePath());
        }
        catch(IOException e)
        {
            log.error("File is not in suitable type to upload");
        }




      return "";
    }



}






